
<!-- leya asmerom
  student id: 104549057-->
  
<?php
// Establish a database connection
$servername = "localhost";
$username = "root";
$password = "Group101";
$database = "chompt";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get asset_id from the URL
if (isset($_GET['asset_id'])) {
    $asset_id = $_GET['asset_id'];

    // Execute a SQL query to retrieve asset details based on asset_id
    $query = "SELECT * FROM asset WHERE id = $asset_id";
    $result = $conn->query($query);

    // Check if the query was successful and display asset details
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Asset Information</title>
            <link href="csslist.css" rel="stylesheet" />
        </head>
        <body>

        <header class="background">
            <!-- FISH LOGO THAT ALSO A LINK TO MAIN PAGE -->
            <div class="logo">
                <a href="../connection.php">
                    <img src="../images/finallogo.png" alt="Chompt logo">
                </a>
            </div>
            <!-- SEARCHBAR -->
            <div class="search-container">
                <input class="searchbar" type="text" placeholder="Discover Your Next Move" id="searchInput">
                <button class="search-clear-button" id="clearButton">X</button>
                <button class="search-button" onclick="search()">
                    <img src="../images/search.png" alt="Search" class="search-icon">
                </button>
            </div>
            <!-- USER ICON WITH POPUP OPTION -->
            <div class="usericon">
                <img src="../images/usericon.png" alt="User" class="user-icon">
            </div>
            <div class="user-popup" id="userPopup">
                <ul>
                    <li><a href="../tradehistory/trades.php">ALL TRADES</a></li>
                    <li><a href="../watchlist/wishlist.php">WATCHLIST</a></li>
                </ul>
            </div>
        </header>

        <div class="column">
            <!-- Display the asset image -->
            <img class="imagesize" src="../images/assetimages/<?php echo $row['image']; ?>" alt="image">

            <!-- Display asset name -->
            <div class="namedate">
                <h2><?php echo isset($row['asset_name']) ? $row['asset_name'] : 'N/A'; ?></h2>
            </div>

            <!-- Display date added -->
            <div class="date">
                <p>Date Added: <?php echo isset($row['date_added']) ? $row['date_added'] : 'N/A'; ?></p>
            </div>

            <!-- Display category -->
            <div class="category">
                <p>Category: <?php echo isset($row['category']) ? $row['category'] : 'N/A'; ?></p>
            </div>

            <!-- Display description -->
            <div class="price">
                <p>price: <?php echo isset($row['asset_price']) ? $row['asset_price'] : 'N/A'; ?></p>
            </div>
        </div>
        <div class="button-container">
        <a href="../connection.php" class="backbtn">Back to Catalog</a>
        <a href="../transaction/transaction_form.php?price=<?php echo $row['asset_price']; ?>" class="purchasebtn">Purchase</a>
        </div>

        
        <form class="wish" action="../watchlist/addToWishlist.php" method="post">
    <input type="hidden" name="asset_name" value="<?php echo $row['asset_name']; ?>">
    <input type="hidden" name="date_added" value="<?php echo $row['date_added']; ?>">
    <input type="hidden" name="asset_price" value="<?php echo $row['asset_price']; ?>">
    <button type="submit" class="wishlist-button">Add to Wishlist</button>
</form>





        <script src="../script.js"></script>

        </body>
        </html>
        <?php
    } else {
        echo "Asset not found";
    }
} else {
    echo "No asset selected";
}

// Close the database connection
$conn->close();
?>
