<!-- leya asmerom
  student id: 104549057-->

<?php
//Establish a database connection
$servername = "localhost";
$username = "root";
$password = "Group101";
$database = "chompt";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Define default values for form fields
    $sender = 'N/A';
    $receiver = 'N/A';
    $amount = 0;
    $asset_type = 'N/A';

    // Check if the 'sender' key exists in the $_POST array
    if (isset($_POST['sender'])) {
        // Retrieve the value of the 'sender' key
        $sender = $_POST['sender'];
    }

    // Check if the 'receiver' key exists in the $_POST array
    if (isset($_POST['receiver'])) {
        // Retrieve the value of the 'receiver' key
        $receiver = $_POST['receiver'];
    }

    // Check if the 'amount' key exists in the $_POST array
    if (isset($_POST['amount'])) {
        // Retrieve the value of the 'amount' key
        $amount = $_POST['amount'];
    }

    // Check if the 'asset_type' key exists in the $_POST array
    if (isset($_POST['asset_type'])) {
        // Retrieve the value of the 'asset_type' key
        $asset_type = $_POST['asset_type'];
    }

    // Store transaction information in the database
    $insertTransactionQuery = "INSERT INTO transaction (sender, receiver, amount, asset_type) VALUES ('$sender', '$receiver', $amount, '$asset_type')";

    if ($conn->query($insertTransactionQuery) === true) {
        // Redirect to the confirmation page after a successful transaction
        header("Location: confirmation.html");
        exit; // Terminate the script to prevent further execution
    } else {
        echo "Error: " . $insertTransactionQuery . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

