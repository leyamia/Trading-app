
<!-- leya asmerom
  student id: 104549057-->
  
<!DOCTYPE html>
<html>
<head>
    <title>Transaction Form</title>
    <link href="trancss.css" rel="stylesheet" />

</head>
<body>

<header class="background">
            <!-- FISH LOGO THAT ALSO A LINK TO MAIN PAGE -->
            <div class="logo">
                <a href="../connection.php">
                    <img src="../images/finallogo.png" alt="Chompt logo">
                </a>
            </div>
            <!-- SEARCHBAR -->
            <div class="search-container">
                <input class="searchbar" type="text" placeholder="Discover Your Next Move" id="searchInput">
                <button class="search-clear-button" id="clearButton">X</button>
                <button class="search-button" onclick="search()">
                    <img src="../images/search.png" alt="Search" class="search-icon">
                </button>
            </div>
            <!-- USER ICON WITH POPUP OPTION -->
            <div class="usericon">
                <img src="../images/usericon.png" alt="User" class="user-icon">
            </div>
            <div class="user-popup" id="userPopup">
                <ul>
                    <li><a href="../tradehistory/trades.php">ALL TRADES</a></li>
                    <li><a href="../watchlist/wishlist.php">WATCHLIST</a></li>
                </ul>
            </div>
        </header>
    <h1>Transaction Form</h1>

    <?php
    // Check if the 'price' query parameter is set in the URL
    if (isset($_GET['price'])) {
        // Retrieve the price from the URL and set it as the default value for 'amount'
        $price = $_GET['price'];
    } else {
        // Handle the case where 'price' is not set (provide a default value or error handling)
        $price = 0; // You can set a default price
    }
    ?>
<section class="container">
    <form method="post" action="process_transaction.php">
        <label for="sender">Username:</label>
        <input class="input" type="text" id="sender" name="sender" required>

        <label for="receiver">Receiver:</label>
        <input class="input"type="text" id "receiver" name="receiver" required>

        <!-- Pre-fill 'amount' input with the retrieved price -->
        <label for="amount">Amount:</label>
        <input class="input"type="number" id="amount" name="amount" value="<?php echo $price; ?>" required>


<!-- Digital Asset (Radio Buttons) -->
<label for="asset_type">Digital Asset:</label>
<input class="input"type="radio" id="btc" name="asset_type" value="BTC" required>
<label for="btc">Bitcoin (BTC)</label>
<input class="input"type="radio" id="eth" name="asset_type" value="ETH">
<label for="eth">Ethereum (ETH)</label>
<input class="input"type="radio" id="nft" name="asset_type" value="NFT">
<label for="nft">NFT</label>


        <!-- Submit Button -->
        <input type="submit" value="Submit Transaction">
    </form>
</section>



    <script src="../script.js"></script>

</body>
</html>
