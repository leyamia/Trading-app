<!-- leya asmerom
  student id: 104549057-->
<?php
// Establish a database connection
$servername = "localhost";
$username = "root";
$password = "Group101";
$database = "chompt";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the asset_id from the form
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['asset_id'])) {
    $asset_id = $_POST['asset_id'];

    // Execute a SQL query to remove the asset from the wishlist
    $removeFromWishlistQuery = "DELETE FROM wishlist WHERE id = $asset_id";
    
    if ($conn->query($removeFromWishlistQuery) === true) {
        $message = "Asset removed from the wishlist!";
    } else {
        $message = "Error: " . $removeFromWishlistQuery . "<br>" . $conn->error;
    }
} else {
    $message = "Invalid request.";
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Transaction Sent !</title>
<link rel="stylesheet" href="./errorstyles.css">
</head>
<body>
    <img src="../Images/sentfish.png" alt="Search" class="search-icon">
    <h1>
        <span class="message"><?php echo $message; ?></span>
    </h1>
    <p class="return"> Please return to the <a href="../connection.php">Main Page</a> to continue your journey  </p>
</body>
</html>
