<!-- leya asmerom
  student id: 104549057-->

<?php
//  Establish a database connection
$servername = "localhost";
$username = "root";
$password = "Group101";
$database = "chompt";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//  Retrieve wishlist items from the database
$query = "SELECT * FROM wishlist";
$result = $conn->query($query);
?>

<!DOCTYPE html>
        <html>
        <head>
            <title>Asset Information</title>
            <link href="wishliststyle.css" rel="stylesheet" />
        </head>
        <body>

        <header class="background">
            <!-- FISH LOGO THAT ALSO A LINK TO MAIN PAGE -->
            <div class="logo">
                <a href="../connection.php">
                    <img src="../images/finallogo.png" alt="Chompt logo">
                </a>
            </div>
            <!-- SEARCHBAR -->
            <div class="search-container">
                <input class="searchbar" type="text" placeholder="Discover Your Next Move" id="searchInput">
                <button class="search-clear-button" id="clearButton">X</button>
                <button class="search-button" onclick="search()">
                    <img src="../images/search.png" alt="Search" class="search-icon">
                </button>
            </div>
            <!-- USER ICON WITH POPUP OPTION -->
            <div class="usericon">
                <img src="../images/usericon.png" alt="User" class="user-icon">
            </div>
            <div class="user-popup" id="userPopup">
                <ul>
                    <li><a href="../tradehistory/trades.php">ALL TRADES</a></li>
                    <li><a href="../watchlist/wishlist.php">WATCHLIST</a></li>
                </ul>
            </div>
        </header>

<h1>My watchlist</h1>

<div class="wishlist-items">
    <?php
    //  Loop through the wishlist items and display them
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Inside the loop that displays wishlist items
echo "<div class='wishlist-item'>";
echo "<h3>" . $row["asset_name"] . "</h3>";
echo "<p>Date Added: " . $row["date_added"] . "</p>";
echo "<p>Price: $" . $row["asset_price"] . "</p>";
echo "<p>Category: " . $row["category"] . "</p>";
echo "<form action='removeFromWishlist.php' method='post'>";
echo "<input type='hidden' name='asset_id' value='" . $row["id"] . "'>";
echo "<button type='submit' class='remove-button'>Remove</button>";
echo "</form>";
echo "</div>";

        }
    } else {
        echo "<p>Your wishlist is empty.</p>";
    }

    // Close the database connection
    $conn->close();
    ?>
</div>
<script src="../script.js"></script>

<a class="back" href="../connection.php">Back to Home</a>

</body>
</html>
