<?php
//  leya asmerom
  // student id: 104549057

//Establish a database connection
$servername = "localhost";
$username = "root";
$password = "Group101";
$database = "chompt";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//  Get the asset details from the form
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['asset_name'])) {
    $asset_name = $_POST['asset_name'];
    $date_added = $_POST['date_added'];
    $asset_price = $_POST['asset_price'];

    // Check if the asset is not already in the wishlist
    $checkQuery = "SELECT * FROM wishlist WHERE asset_name = '$asset_name' AND date_added = '$date_added' AND asset_price = $asset_price";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult->num_rows === 0) {
        //Retrieve asset details
        $getAssetQuery = "SELECT * FROM asset WHERE asset_name = '$asset_name'";
        $getAssetResult = $conn->query($getAssetQuery);
        
        if ($getAssetResult->num_rows === 1) {
            $row = $getAssetResult->fetch_assoc();
            $category = $row['category'];

            // Execute a SQL query to add the asset to the wishlist
            $addToWishlistQuery = "INSERT INTO wishlist (asset_name, date_added, asset_price, category) VALUES ('$asset_name', '$date_added', $asset_price, '$category')";
            if ($conn->query($addToWishlistQuery) === true) {
                $message = "Asset added to the wishlist!";
            } else {
                $message = "Error: " . $addToWishlistQuery . "<br>" . $conn->error;
            }
        } else {
            $message = "Asset not found.";
        }
    } else {
        $message = "Asset is already in the wishlist.";
    }
} else {
    $message = "Invalid request.";
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Wishlist added !</title>
<link rel="stylesheet" href="./errorsubmission.css">
</head>
<body>
    <img src="../Images/sentfish.png" alt="Search" class="search-icon">
    <h1>
        <span class="message"><?php echo $message; ?></span>
    </h1>
    <p class="return">Please return to the <a href="../connection.php">Main Page</a> to continue your journey</p>
</body>
</html>



