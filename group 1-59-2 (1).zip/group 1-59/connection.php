<!-- leya asmerom
  student id: 104549057-->


<?php
//Establish a database connection
$servername = "localhost";
$username = "root";
$password = "Group101";
$database = "chompt";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//Execute a SQL query to retrieve the data
$query = "SELECT * FROM asset";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Product Catalog</title>
    <link rel="stylesheet" type="text/css" href="connstyles.css">
</head>
<body>

<header class="background">
    <!--FISH LOGO THAT ALSO A LINK TO MAIN PAGE-->
    <div class="logo">
      <a href="./connection.php">
        <img src="./Images/finallogo.png" alt="Chompt logo">
      </a>
    </div>
    <!--SEARCHBAR-->
		<div class="search-container">
		  <input class="searchbar" type="text" placeholder="Discover Your Next Move" id="searchInput">
		  <button class="search-clear-button" id="clearButton">X</button>
		  <button class="search-button" onclick="search()">
			<img src="./Images/search.png" alt="Search" class="search-icon">
		  </button>
		</div>
    <!--USER ICON WITH POPUP OPTION -->
    <div class="usericon">
      <img src="./Images/usericon.png" alt="User" class="user-icon">
    </div>
    <div class="user-popup" id="userPopup">
      <ul>
        <li><a href="./tradehistory/trades.php">ALL TRADES</a></li>
        <li><a href="./watchlist/wishlist.php">WATCHLIST</a></li>
      </ul>
    </div>
  </header>

<!--TRENDING TRADES -->
<section class="trending">
  <h1>Trending Now</h1>
  
  <div class="carousel-container">
    <div class="carousel-slide">
      <?php
      // Use PHP to fetch images from the database and display them
      $trendingImages = [
        ["filename" => "art1.jpg", "asset_id" => 1],
        ["filename" => "music3.jpg", "asset_id" => 4],
        ["filename" => "game3.jpg", "asset_id" => 7],
        ["filename" => "photo3.jpg", "asset_id" => 10]
      ];

      foreach ($trendingImages as $imageInfo) {
        $imageFilename = $imageInfo["filename"];
        $assetId = $imageInfo["asset_id"];

        // Create a link to assetinfo.php with the asset_id
        echo "<a href='assetlist/assetinfo.php?asset_id=$assetId'>";
        echo "<img src='../group 1-59/Images/assetimages/$imageFilename' alt='Trending Image'>";
        echo "</a>";
      }
      ?>
    </div>
  </div>
</section>

    
  <!--SLOGAN-->
  <div>
    <h1 class="Typing">More to sea in.<br></h1>
    <h2 class="Confidence">Chompt!</h2>

   <a href="#options" class="start">Get Started</a>
  </div>

  <section >
  <!-- Options to filter assets by category -->
<div id="options" class="newassets">
    <a href="#art-text" onclick="filterAssets('Art')">ART</a>
    <a href="#photography-text" onclick="filterAssets('Photography')">PHOTOGRAPHY</a>
    <a href="#music-text" onclick="filterAssets('Music')">MUSIC</a>
    <a href="#game-text" onclick="filterAssets('Game')">GAME</a>
</div>


<div class="product-cards">
<?php


//Loop through the query result and format it into product cards
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<a href='assetlist/assetinfo.php?asset_id=" . $row['id'] . "' class='product-card'>";
        echo "<div class='product-image'>";
        if (!empty($row['image'])) {
            echo "<img src='../group 1-59/Images/assetimages/" . $row['image'] . "' alt='Product Image'>";
        }
        echo "</div>";
        
        echo "<div class='product-details'>";
        echo "<h3>" . $row['asset_name'] . "</h3>";
        echo "<p>Date Added: " . $row['date_added'] . "</p>";
        echo "<p>Price: $" . $row['asset_price'] . "</p>";
        echo "<p>Category: " . $row['category'] . "</p>";
        echo "<p>Creator: " . $row['creator'] . "</p>";
        echo "</div>";
        echo "</a>";
    }
} else {
    echo "<p>No data found</p>";
}

//Close the database connection
$conn->close();
?>

</div>
<script src="script.js"></script>

</body>
</html>
