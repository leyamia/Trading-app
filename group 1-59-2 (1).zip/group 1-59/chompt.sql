/*-- leya asmerom
  student id: 104549057*/

CREATE DATABASE  IF NOT EXISTS `chompt` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `chompt`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: chompt
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `asset`
--

DROP TABLE IF EXISTS `asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset` (
  `id` int NOT NULL,
  `asset_name` varchar(20) NOT NULL,
  `date_added` date NOT NULL,
  `asset_price` float NOT NULL,
  `category` varchar(15) NOT NULL,
  `creator` varchar(15) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`,`asset_name`,`creator`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset`
--

LOCK TABLES `asset` WRITE;
/*!40000 ALTER TABLE `asset` DISABLE KEYS */;
INSERT INTO `asset` VALUES (1,'Ourreflction','2023-03-02',0.22,'ART','swindlepug','art1.jpg'),(2,'Loney Sunday','2022-12-13',1.34,'ART','Fairygoose32','art2.jpg'),(3,'Bearie Nice','2019-07-11',4.82,'ART','BeaBea1','art3.jpg'),(4,'m.A.A.d city','2012-10-22',11.21,'MUSIC','Kendr1ck','music3.jpg'),(5,'Around the Fur','1997-10-27',8.72,'MUSIC','Deft0nes','music1.jpg'),(6,'Channel Orange','2012-07-10',2.76,'MUSIC','FrankSea','music2.jpg'),(7,'Call of Duty','2017-11-02',0.32,'GAME','Gameblob','game3.jpg'),(8,'Resident Evil 2','2019-01-25',1.02,'GAME','zombieislife','game1.jpg'),(9,'Horizon dawn','2017-02-28',2.46,'GAME','oversunset','game2.jpg'),(10,'InConnect','2021-07-04',0.04,'PHOTO','stawberri','photo3.jpg'),(11,'Apple Sim','2016-04-13',1.2,'PHOTO','bluebells','photo1.jpg'),(12,'impasso','2018-12-14',3.2,'PHOTO','artistkatt','photo2.jpg');
/*!40000 ALTER TABLE `asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender` varchar(255) NOT NULL,
  `receiver` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `asset_type` varchar(50) NOT NULL,
  `transaction_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (1,'yy','',3.00,'BTC','2023-10-15 06:11:53'),(2,'leya','',1.00,'NFT','2023-10-15 06:12:58'),(3,'leya','',1.00,'NFT','2023-10-15 06:13:50'),(4,'leya','N/A',1.00,'ETH','2023-10-15 06:14:25'),(5,'w','ww',1.34,'BTC','2023-10-15 06:19:24'),(6,'yy','gg',2.76,'NFT','2023-10-15 06:34:23'),(7,'leya','gg',2.76,'BTC','2023-10-15 06:41:02'),(8,'yy','gg',0.22,'BTC','2023-10-15 06:43:19'),(9,'w','w',0.22,'ETH','2023-10-15 06:45:07'),(10,'mew','lew',1.34,'ETH','2023-10-15 06:58:27'),(11,'leya','gg',4.82,'ETH','2023-10-15 07:24:05');
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wishlist`
--

DROP TABLE IF EXISTS `wishlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wishlist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `asset_name` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL,
  `asset_price` float NOT NULL,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlist`
--

LOCK TABLES `wishlist` WRITE;
/*!40000 ALTER TABLE `wishlist` DISABLE KEYS */;
INSERT INTO `wishlist` VALUES (1,'Ourreflction','2023-03-02 00:00:00',0.22,'ART'),(3,'Ourreflction','2023-03-02 00:00:00',0.22,'ART'),(4,'Ourreflction','2023-03-02 00:00:00',0.22,'ART');
/*!40000 ALTER TABLE `wishlist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-14 20:45:03
