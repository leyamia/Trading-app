<!-- leya asmerom
  student id: 104549057-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Past Trades</title>
    <link rel="stylesheet" href="tradecss.css"> 
</head>
<body>

<header class="background">
            <!-- FISH LOGO THAT ALSO A LINK TO MAIN PAGE -->
            <div class="logo">
                <a href="../connection.php">
                    <img src="../images/finallogo.png" alt="Chompt logo">
                </a>
            </div>
            <!-- SEARCHBAR -->
            <div class="search-container">
                <input class="searchbar" type="text" placeholder="Discover Your Next Move" id="searchInput">
                <button class="search-clear-button" id="clearButton">X</button>
                <button class="search-button" onclick="search()">
                    <img src="../images/search.png" alt="Search" class="search-icon">
                </button>
            </div>
            <!-- USER ICON WITH POPUP OPTION -->
            <div class="usericon">
                <img src="../images/usericon.png" alt="User" class="user-icon">
            </div>
            <div class="user-popup" id="userPopup">
                <ul>
                    <li><a href="../tradehistory/trades.php">ALL TRADES</a></li>
                    <li><a href="../watchlist/wishlist.php">WATCHLIST</a></li>
                </ul>
            </div>
        </header>

    <h1>Past Trades</h1>

    <?php
// Establish a database connection
$servername = "localhost";
$username = "root";
$password = "Group101";
$database = "chompt";

$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

    // Execute a SQL query to retrieve past trades data
    $query = "SELECT * FROM transaction"; // Replace 'tansaction' with your table name
    $result = $conn->query($query);

    // Display past trades data
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>Sender</th><th>Receiver</th><th>Amount</th><th>Asset Type</th></tr>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['sender'] . "</td>";
            echo "<td>" . $row['receiver'] . "</td>";
            echo "<td>" . $row['amount'] . "</td>";
            echo "<td>" . $row['asset_type'] . "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    } else {
        echo "<p>No past trades found.</p>";
    }

    // Close the database connection
    $conn->close();
    ?>
        <script src="../script.js"></script>

</body>
</html>
