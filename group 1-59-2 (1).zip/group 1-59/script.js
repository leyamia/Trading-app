//leya asmerom 
//(104549057)

// popup menu
document.addEventListener("DOMContentLoaded", function () {
    const userIcon = document.querySelector(".user-icon");
    const userPopup = document.querySelector("#userPopup");
  
    userIcon.addEventListener("click", function (event) {
      event.stopPropagation();
  
      if (userPopup.style.display === "block") {
        userPopup.style.display = "none";
      } else {
        userPopup.style.display = "block";
      }
    });
  
    document.addEventListener("click", function () {
      userPopup.style.display = "none";
    });
  
    userPopup.addEventListener("click", function (event) {
      event.stopPropagation();
    });
  });

  
 //  event listener for keypress on the search input field
const searchInput = document.getElementById("searchInput");

searchInput.addEventListener("keypress", function (event) {
  if (event.key === "Enter") {
    // Prevent the default form submission behavior
    event.preventDefault();

    // Call the search function when Enter key is pressed
    search();
  }
});

function search() {
  // Get the search input value
  var searchValue = document.getElementById("searchInput").value.toLowerCase();
  
  // Get all table rows
  var tableRows = document.querySelectorAll("table tr");
  
  // Loop through the rows and hide/show based on the search value
  for (var i = 1; i < tableRows.length; i++) {
      var row = tableRows[i];
      var assetName = row.getElementsByTagName("td")[0].textContent.toLowerCase();
      
      if (assetName.includes(searchValue)) {
          row.style.display = "";
      } else {
          row.style.display = "none";
      }
  }
}
{
  // Clear the search input field
  searchInput.value = "";
}

document.getElementById('clearButton').addEventListener('click', function() {
  document.getElementById('searchInput').value = '';
});


//
const carouselSlide = document.querySelector(".carousel-slide");
const images = document.querySelectorAll(".carousel-slide img");

let counter = 0;
const imageCount = images.length;
const slideWidth = 100; 

function nextSlide() {
  if (counter >= imageCount - 1) {
    counter = 0;
    carouselSlide.style.transition = "none"; 
  } else {
    counter++;
    carouselSlide.style.transition = "transform 1s ease-in-out";
  }
  carouselSlide.style.transform = `translateX(${-counter * slideWidth}%)`;
}

setInterval(nextSlide, 3000);


